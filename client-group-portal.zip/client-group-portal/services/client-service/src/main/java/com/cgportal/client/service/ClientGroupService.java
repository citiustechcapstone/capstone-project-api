package com.cgportal.client.service;

import jakarta.transaction.Transactional;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import com.cgportal.client.dto.ClientGroupDto;
import com.cgportal.client.mapper.ClientGroupMapper;
import com.cgportal.client.model.ClientGroup;
import com.cgportal.client.repo.ClientGroupRepository;

import java.time.LocalDate; 
@Service
public class ClientGroupService {

	  private final ClientGroupRepository repo;
	  private final ClientGroupMapper mapper;
	  private final HierarchyValidator guard;
	 
	  public ClientGroupService(ClientGroupRepository repo, ClientGroupMapper mapper, HierarchyValidator guard) {
	    this.repo = repo; this.mapper = mapper; this.guard = guard;
	  }
	 
	  public Page<ClientGroupDto> search(String groupId, String groupName, String cCode, Pageable pageable) {
	    return repo
	      .findByGroupIdContainingAndGroupNameContainingIgnoreCaseAndCCodeContainingIgnoreCase(
	        groupId == null ? "" : groupId,
	        groupName == null ? "" : groupName,
	        cCode == null ? "" : cCode, pageable)
	      .map(mapper::toDto);
	  }
	 
	  @Transactional
	  public ClientGroupDto create(ClientGroupDto dto) {
	    // basic date rule: effective <= termination (if both present)
	    if (dto.getEffectiveDate()!=null && dto.getTerminationDate()!=null &&
	        dto.getEffectiveDate().isAfter(dto.getTerminationDate()))
	      throw new IllegalArgumentException("effectiveDate must be <= terminationDate");
	 
	    ClientGroup entity = mapper.toEntity(dto);
	    if (entity.getEffectiveDate()==null) entity.setEffectiveDate(LocalDate.now());
	    guard.assertValid(entity);
	    repo.findByGroupId(entity.getGroupId()).ifPresent(x -> { throw new IllegalArgumentException("groupId exists");});
	    repo.findBycCode(entity.getcCode()).ifPresent(x -> { throw new IllegalArgumentException("cCode exists");});
	    var saved = repo.save(entity);
	    return mapper.toDto(saved);
	  }
	 
	  public ClientGroupDto get(Long id) {
	    return mapper.toDto(repo.findById(id).orElseThrow());
	  }
	 
	  @Transactional
	  public ClientGroupDto update(Long id, ClientGroupDto dto) {
	    var entity = repo.findById(id).orElseThrow();
	    mapper.update(entity, dto);
	    guard.assertValid(entity);
	    if (entity.getEffectiveDate()!=null && entity.getTerminationDate()!=null &&
	        entity.getEffectiveDate().isAfter(entity.getTerminationDate()))
	      throw new IllegalArgumentException("effectiveDate must be <= terminationDate");
	    entity.setUpdatedAt(entity.getUpdatedAt().now());
	    return mapper.toDto(repo.save(entity));
	  }
	}