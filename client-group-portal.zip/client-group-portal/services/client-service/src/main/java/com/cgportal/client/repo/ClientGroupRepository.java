package com.cgportal.client.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cgportal.client.model.ClientGroup;

import java.util.Optional;
 
public interface ClientGroupRepository extends JpaRepository<ClientGroup, Long> {
  Optional<ClientGroup> findByGroupId(String groupId);
  Optional<ClientGroup> findBycCode(String cCode);
  Optional<ClientGroup> findByparentGroupId(Long parentGroupId);
  Page<ClientGroup> findByGroupIdContainingAndGroupNameContainingIgnoreCaseAndCCodeContainingIgnoreCase(
      String groupId, String groupName, String cCode, Pageable pageable);
}