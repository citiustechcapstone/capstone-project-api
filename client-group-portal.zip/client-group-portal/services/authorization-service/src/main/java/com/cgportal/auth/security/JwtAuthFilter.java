package com.cgportal.auth.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import com.cgportal.auth.service.UserDetailsServiceImpl;

import java.io.IOException;
import java.util.List;

@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

	private final JwtService jwtService;
	private final UserDetailsServiceImpl userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String authHeader = request.getHeader("Authorization");
		if (authHeader != null && authHeader.startsWith("Bearer ")) {
			String token = authHeader.substring(7);
			String username = jwtService.extractUsername(token);
			String role = jwtService.extractRole(token); // Implement this in JwtService

			if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
				UserDetails userDetails = userDetailsService.loadUserByUsername(username);
				List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(role)); // e.g., ROLE_ADMIN

				
				UsernamePasswordAuthenticationToken authToken =
				    new UsernamePasswordAuthenticationToken(userDetails, null, authorities);

				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authToken);
				System.out.println("Authentication set for user: " + username + " with role: " + role);
			}
		}

		filterChain.doFilter(request, response);
	}
}
//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//			throws ServletException, IOException {
//
//		String authHeader = request.getHeader("Authorization");
//		if (authHeader != null && authHeader.startsWith("Bearer ")) {
//			String token = authHeader.substring(7);
//			String username = jwtService.extractUsername(token); // or extractRole if needed
//			String role = jwtService.extractRole(token);
//
//			if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
//				List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(role)); // e.g., ROLE_ADMIN
//
//				UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(username, null,
//						authorities);
//
//				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//				SecurityContextHolder.getContext().setAuthentication(authToken);
//				System.out.println("JwtAuthFilter triggered for: " + request.getRequestURI());
//
//			}
//		}
//
//		filterChain.doFilter(request, response);
//	}
