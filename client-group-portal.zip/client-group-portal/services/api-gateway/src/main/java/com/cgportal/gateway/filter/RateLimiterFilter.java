package com.cgportal.gateway.filter;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Component
public class RateLimiterFilter implements GlobalFilter, Ordered {
 
    @Value("${app.rate-limit.capacity:100}")
    private int capacity;
 
    @Value("${app.rate-limit.refillTokens:50}")
    private int refillTokens;
 
    @Value("${app.rate-limit.refillPeriodSeconds:60}")
    private int refillPeriodSeconds;
 
    private static class Bucket {
        AtomicInteger tokens = new AtomicInteger(0);
        long lastRefill = Instant.now().getEpochSecond();
    }
 
    private final Map<String, Bucket> buckets = new ConcurrentHashMap<>();
 
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, org.springframework.cloud.gateway.filter.GatewayFilterChain chain) {
        String key = exchange.getRequest().getHeaders().getFirst("X-Forwarded-For");
        if (key == null) key = exchange.getRequest().getRemoteAddress() != null ?
                exchange.getRequest().getRemoteAddress().getAddress().getHostAddress() : "unknown";
 
        Bucket b = buckets.computeIfAbsent(key, k -> new Bucket());
        long now = Instant.now().getEpochSecond();
        long delta = now - b.lastRefill;
        if (delta >= refillPeriodSeconds) {
            int newTokens = Math.min(capacity, b.tokens.get() + refillTokens);
            b.tokens.set(newTokens);
            b.lastRefill = now;
        }
        if (b.tokens.getAndUpdate(t -> t>0 ? t-1 : 0) <= 0) {
            exchange.getResponse().setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
            return exchange.getResponse().setComplete();
        }
        return chain.filter(exchange);
    }
 
    @Override
    public int getOrder() { return -100; }
}