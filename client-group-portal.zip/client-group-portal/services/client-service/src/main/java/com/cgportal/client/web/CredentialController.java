package com.cgportal.client.web;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.cgportal.client.dto.CreateCredentialRequest;
import com.cgportal.client.dto.CreateCredentialResponse;
import com.cgportal.client.service.CredentialService;

@RestController
@RequestMapping("/clients/{clientId}/credentials")
@RequiredArgsConstructor
public class CredentialController {
//
// private final CredentialService service;
//
// @PostMapping
// public ResponseEntity<CreateCredentialResponse> create(@PathVariable Long clientId,
//                                                        @RequestBody @Valid CreateCredentialRequest req,
//                                                        @RequestHeader(HttpHeaders.AUTHORIZATION) String bearer,
//                                                        Authentication principal) {
//     requireAdmin(principal);
//     return ResponseEntity.ok(service.createCredentials(clientId, bearer, req));
// }
//
// private void requireAdmin(Authentication principal) {
//     if (principal == null || principal.getAuthorities().stream().noneMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
//         throw new IllegalArgumentException("Admin privileges required");
//     }
// }
}
