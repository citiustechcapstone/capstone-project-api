package com.cgportal.client.model;

import jakarta.persistence.*;
import lombok.*;
 
import java.time.LocalDate;
 
@Entity
@Table(name="product_enrollments", indexes = @Index(name="idx_products_client", columnList = "client_group_id"))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ProductEnrollment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    @Column(name="client_group_id", nullable=false)
    private Long clientGroupId;
 
    @Enumerated(EnumType.STRING)
    @Column(name="product_type", nullable=false, length=32)
    private ProductType productType;
 
    @Column(name="description", nullable=false, length=255)
    private String description;
 
    private LocalDate effectiveDate;
    private LocalDate terminationDate;
}