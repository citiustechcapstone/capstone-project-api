package com.cgportal.client.web;

import java.time.OffsetDateTime;
import java.util.Map;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;

@RestControllerAdvice
public class ErrorAdvice {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> badRequest(MethodArgumentNotValidException ex) {
		return ResponseEntity.badRequest().body(problem(400, "Validation failed", ex.getMessage()));
	}

	@ExceptionHandler({ IllegalArgumentException.class, IllegalStateException.class })
	public ResponseEntity<?> invalid(RuntimeException ex) {
		return ResponseEntity.badRequest().body(problem(400, "Bad Request", ex.getMessage()));
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> boom(Exception ex) {
		return ResponseEntity.status(500).body(problem(500, "Internal Server Error", ex.getMessage()));
	}

	private Map<String, Object> problem(int status, String title, String detail) {
		return Map.of("type", "about:blank", "title", title, "status", status, "detail", detail, "timestamp",
				OffsetDateTime.now().toString());
	}
}
