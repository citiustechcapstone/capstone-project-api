package com.cgportal.client.mapper;

import com.cgportal.client.dto.ContactDto;
import com.cgportal.client.model.Contact;

import org.mapstruct.*;
 
@Mapper(componentModel = "spring")
public interface ContactMapper {
  ContactDto toDto(Contact e);
  Contact toEntity(ContactDto dto);
 
  @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
  void update(@MappingTarget Contact target, ContactDto src);
}