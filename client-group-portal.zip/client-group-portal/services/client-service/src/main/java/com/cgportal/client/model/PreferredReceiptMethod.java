package com.cgportal.client.model;

public enum PreferredReceiptMethod { EMAIL, FAX }
