package com.cgportal.client.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cgportal.client.model.Contact;

import java.util.List;
 
public interface ContactRepository extends JpaRepository<Contact, Long> {
    List<Contact> findByClientGroupId(Long clientId);
}