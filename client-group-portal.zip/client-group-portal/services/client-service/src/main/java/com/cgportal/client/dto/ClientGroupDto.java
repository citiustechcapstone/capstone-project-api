package com.cgportal.client.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class ClientGroupDto {
	Long id;
	@Pattern(regexp="\\d{10}") @NotBlank String groupId;
    Long parentGroupId;
    @NotBlank String cCode;
    @NotBlank String groupName;
    @NotNull LocalDate effectiveDate;
    @NotNull LocalDate terminationDate;
    @NotBlank String address1;
    String address2;
    @NotBlank String city;
    @NotBlank String state;
    @NotBlank String zip;
    @NotBlank String phone;
    String status;
    
    public ClientGroupDto() {
		super();
		// TODO Auto-generated constructor stub
	}
//	public ClientGroupDto(Long id, @Pattern(regexp = "\\d{10}") @NotBlank String groupId, Long parentGroupId,
//			@NotBlank String cCode, @NotBlank String groupName, @NotNull LocalDate effectiveDate,
//			@NotNull LocalDate terminationDate, @NotBlank String address1, String address2, @NotBlank String city,
//			@NotBlank String state, @NotBlank String zip, @NotBlank String phone, String status) {
//		super();
//		this.id = id;
//		this.groupId = groupId;
//		this.parentGroupId = parentGroupId;
//		this.cCode = cCode;
//		this.groupName = groupName;
//		this.effectiveDate = effectiveDate;
//		this.terminationDate = terminationDate;
//		this.address1 = address1;
//		this.address2 = address2;
//		this.city = city;
//		this.state = state;
//		this.zip = zip;
//		this.phone = phone;
//		this.status = status;
//	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public Long getParentGroupId() {
		return parentGroupId;
	}
	public void setParentGroupId(Long parentGroupId) {
		this.parentGroupId = parentGroupId;
	}
	public String getcCode() {
		return cCode;
	}
	public void setcCode(String cCode) {
		this.cCode = cCode;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public LocalDate getTerminationDate() {
		return terminationDate;
	}
	public void setTerminationDate(LocalDate terminationDate) {
		this.terminationDate = terminationDate;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
