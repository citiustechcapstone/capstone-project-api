package com.cgportal.client.model;

public enum ProductType { GROUP_HEALTH, FULLY_INSURED, SELF_INSURED }