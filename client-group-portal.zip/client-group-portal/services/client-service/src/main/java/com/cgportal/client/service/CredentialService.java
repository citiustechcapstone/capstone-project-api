package com.cgportal.client.service;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.cgportal.client.dto.CreateCredentialRequest;
import com.cgportal.client.dto.CreateCredentialResponse;

import reactor.core.publisher.Mono;
 
import java.security.SecureRandom;
 
@Service
@RequiredArgsConstructor
public class CredentialService {
 
//    private final WebClient.Builder webClientBuilder;
// 
//    @Value("${cgp.services.auth.base-url:http://localhost:8081}")
//    private String authBaseUrl;
// 
//    public CreateCredentialResponse createCredentials(Long clientGroupId, String bearerToken, @Valid CreateCredentialRequest req) {
//        String tempPassword = generateTempPassword();
// 
//        var body = new AuthRegisterPayload(req.getUsername(), tempPassword, "CLIENT", clientGroupId);
// 
//        WebClient client = webClientBuilder.baseUrl(authBaseUrl).build();
//        client.post().uri("/auth/register")
//                .header(HttpHeaders.AUTHORIZATION, bearerToken)
//                .contentType(MediaType.APPLICATION_JSON)
//                .bodyValue(body)
//                .retrieve()
//                .onStatus(s -> s.value() == 401 || s.value() == 403,
//                        r -> Mono.error(new IllegalArgumentException("Not authorized to create credentials")))
//                .toBodilessEntity()
//                .block();
// 
//        return new CreateCredentialResponse(req.getUsername(), tempPassword);
//    }
// 
//    private String generateTempPassword() {
//        // 12-char random with upper/lower/digits
//        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
//        SecureRandom r = new SecureRandom();
//        StringBuilder sb = new StringBuilder();
//        for (int i=0;i<12;i++) sb.append(chars.charAt(r.nextInt(chars.length())));
//        return sb.toString();
//    }
// 
//    private record AuthRegisterPayload(String username, String password, String role, Long clientGroupId) {}
}