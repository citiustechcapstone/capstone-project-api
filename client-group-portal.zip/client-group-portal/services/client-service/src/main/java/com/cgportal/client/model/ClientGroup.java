package com.cgportal.client.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
 
import java.time.LocalDate;
import java.time.Instant;
 
@Entity
@Table(name = "client_groups", indexes = {
        @Index(name="idx_group_id", columnList = "group_id"),
        @Index(name="idx_c_code", columnList = "c_code"),
        @Index(name="idx_group_name", columnList = "group_name")
})
 
@NoArgsConstructor 
@AllArgsConstructor @Builder
public class ClientGroup {
 
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    @Column(name="group_id", nullable=false, length=10, unique = true)
    private String groupId; // 10-digit
 
    @Column(name="parent_group_id")
    private Long parentGroupId; // FK to ClientGroup.id (nullable)
 
    @Column(name="c_code", nullable=false, unique = true, length=64)
    private String cCode;
 
    @Column(name="group_name", nullable=false, length=255)
    private String groupName;
 
    private LocalDate effectiveDate;
    private LocalDate terminationDate;
 
    @Column(name="address1", length=255) private String address1;
    @Column(name="address2", length=255) private String address2;
    @Column(name="city", length=128) private String city;
    @Column(name="state", length=128) private String state;
    @Column(name="zip", length=32) private String zip;
    @Column(name="phone", length=32) private String phone;
    @Column(name="status", length=32) private String status;
 
    @CreationTimestamp @Column(nullable=false, updatable=false)
    private Instant createdAt;
    @UpdateTimestamp
    private Instant updatedAt;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public Long getParentGroupId() {
		return parentGroupId;
	}
	public void setParentGroupId(Long parentGroupId) {
		this.parentGroupId = parentGroupId;
	}
	public String getcCode() {
		return cCode;
	}
	public void setcCode(String cCode) {
		this.cCode = cCode;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public LocalDate getTerminationDate() {
		return terminationDate;
	}
	public void setTerminationDate(LocalDate terminationDate) {
		this.terminationDate = terminationDate;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Instant getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
	public Instant getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}
    

}