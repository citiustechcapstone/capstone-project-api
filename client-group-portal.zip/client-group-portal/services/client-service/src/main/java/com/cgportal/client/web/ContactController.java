package com.cgportal.client.web;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.cgportal.client.dto.ContactDto;
import com.cgportal.client.service.ContactService;

import java.util.List;

@RestController
@RequestMapping("/clients/{clientId}/contacts")
@RequiredArgsConstructor
public class ContactController {

 private final ContactService service;

 @GetMapping
 public List<ContactDto> list(@PathVariable Long clientId) {
     return service.list(clientId);
 }

 @PostMapping
 public ResponseEntity<ContactDto> upsert(@PathVariable Long clientId,
                                          @RequestBody @Valid ContactDto dto,
                                          Authentication principal) {
     requireAdmin(principal);
     if (!clientId.equals(dto.getClientGroupId()))
         throw new IllegalArgumentException("clientGroupId mismatch");
     return ResponseEntity.ok(service.upsert(dto));
 }

 private void requireAdmin(Authentication principal) {
     if (principal == null || principal.getAuthorities().stream().noneMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
         throw new IllegalArgumentException("Admin privileges required");
     }
 }
}
