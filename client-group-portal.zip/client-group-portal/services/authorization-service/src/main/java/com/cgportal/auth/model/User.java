package com.cgportal.auth.model;
 
import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;
 
@Entity
@Table(name = "users", uniqueConstraints = {
        @UniqueConstraint(name="uk_users_username", columnNames = "username")
})
@Getter @Setter @NoArgsConstructor @Builder
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    @Column(nullable = false, length = 255)
    private String username; // email
 
    @Column(nullable = false)
    private String password;
 
    @Column(nullable = false, length = 20)
    private String role; // ADMIN, CLIENT
 
    private String clientGroupId; // nullable
 
    @Column(nullable = false)
    private boolean enabled = true;
 
    @Column(nullable = false)
    private Instant createdAt = Instant.now();

	public User(Long id, String username, String password, String role, String clientGroupId, boolean enabled,
			Instant createdAt) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.role = role;
		this.clientGroupId = clientGroupId;
		this.enabled = enabled;
		this.createdAt = createdAt;
	}
    
    
}