package com.cgportal.client.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
@Configuration
public class OpenAPIConfig {
	@Bean
	  GroupedOpenApi api() {
	    return GroupedOpenApi.builder()
	      .group("client")
	      .pathsToMatch("/clients/**", "/actuator/**")
	      .addOpenApiCustomizer(open -> open.setInfo(new Info().title("Client Service").version("v1")))
	      .build();
	  }
}