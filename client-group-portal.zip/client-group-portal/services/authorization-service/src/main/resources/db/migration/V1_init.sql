CREATE TABLE users (
id               BIGINT AUTO_INCREMENT PRIMARY KEY,
username         VARCHAR(191) NOT NULL,                -- email (login)
password         VARCHAR(255) NOT NULL,                -- BCrypt hash
role             ENUM('ADMIN','CLIENT') NOT NULL,
client_group_id  BIGINT NULL,                          -- logical ref to client_db.client_groups.id
enabled          BOOLEAN NOT NULL DEFAULT TRUE,
created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
updated_at       TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
created_by       VARCHAR(191) NOT NULL DEFAULT 'system',
updated_by       VARCHAR(191) NULL,
CONSTRAINT uq_users_username_client UNIQUE (username, client_group_id)
);

INSERT INTO users
(username, password, role, client_group_id, enabled, created_by)
VALUES
(
  'admin@clientgroup.com',
  '$2a$10$hNqSFFoC.3HqAmW5Yj8AuOZq8QpD7y3bR7DYc6iGZjKnUaa9Mfl2',  -- BCrypt hash for 'Admin@12345'
  'ADMIN',
  NULL,      -- NULL means this Admin is not tied to a specific ClientGroup
  TRUE,
  'system'
);