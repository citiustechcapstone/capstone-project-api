INSERT INTO users (username, password, role, enabled, created_at)
SELECT 'admin@local',
       -- BCrypt for "ChangeMe!123"
       '$2a$10$6Vxw9yH1m3c3bPf7R2m2M.0XoJk9r7Qw8i9QFQPA7wC7V6mFq2hC2',
       'ADMIN',
       1,
       CURRENT_TIMESTAMP(6)
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin@local');