package com.cgportal.client.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import com.cgportal.client.model.ClientGroup;
import com.cgportal.client.repo.ClientGroupRepository;

import java.util.Optional;
 
@Component
public class HierarchyValidator {
 
	 private final ClientGroupRepository repo;
	  public HierarchyValidator(ClientGroupRepository repo) { this.repo = repo; }
	 
	  /**
	   * Enforce 2-level hierarchy:
	   * - parent may have many children
	   * - child must NOT have its own child (max depth 2)
	   * - if creating a "parent" record: parentGroupId must equal groupId (per BRD)
	   */
	  public void assertValid(ClientGroup cg) {
	    // Parent case: Parent Group ID == Group ID
	    if (cg.getParentGroupId() != null && cg.getParentGroupId().equals(cg.getGroupId())) {
	      return; // parent root node (allowed)
	    }
	    // Child case: parentGroupId must exist and be a true parent (its parentGroupId == its own groupId)
	    if (cg.getParentGroupId() != null) {
	      Optional<ClientGroup> parent = repo.findByparentGroupId(cg.getParentGroupId());
	      if (parent.isEmpty()) throw new IllegalArgumentException("Parent groupId not found");
	      ClientGroup p = parent.get();
	      // If the parent itself is a child (i.e., its parentGroupId != its groupId), depth would be 3 → reject
	      if (!p.getGroupId().equals(p.getParentGroupId()))
	        throw new IllegalStateException("Parent already has a parent — would exceed 2-level hierarchy");
	    }
	  }
}