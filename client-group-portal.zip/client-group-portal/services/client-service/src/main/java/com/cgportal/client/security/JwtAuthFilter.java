package com.cgportal.client.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.security.SignatureException;

import java.io.IOException;
import java.util.List;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {
	private final JwtService jwt;

	public JwtAuthFilter(JwtService jwt) {
		this.jwt = jwt;
	}

	@Override
	protected void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response,
			@NonNull FilterChain chain) throws ServletException, IOException {

		String header = request.getHeader(HttpHeaders.AUTHORIZATION);

		if (header != null && header.startsWith("Bearer ")) {
			String token = header.substring(7); // Remove "Bearer " prefix

			try {
				Jws<Claims> jws = jwt.parse(token);
				Claims claims = jws.getBody();

				String username = claims.get("username", String.class);
				String role = claims.get("role", String.class); // e.g., "ROLE_ADMIN"

				if (username != null && role != null) {
					var authorities = List.of(new SimpleGrantedAuthority(role));
					var authToken = new UsernamePasswordAuthenticationToken(username, null, authorities);
					SecurityContextHolder.getContext().setAuthentication(authToken);

					System.out.println("✅ JwtAuthFilter: Authenticated user " + username + " with role " + role);
				}

			} catch (SignatureException e) {
				System.out.println("❌ JwtAuthFilter: Invalid token signature - " + e.getMessage());
				SecurityContextHolder.clearContext();
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.getWriter().write("Invalid JWT signature");
				return;

			} catch (Exception e) {
				System.out.println("❌ JwtAuthFilter: Token parsing failed - " + e.getMessage());
				SecurityContextHolder.clearContext();
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.getWriter().write("Invalid JWT token");
				return;
			}
		}

		System.out.println("JwtAuthFilter triggered for: " + request.getRequestURI());

		chain.doFilter(request, response);
	}

}