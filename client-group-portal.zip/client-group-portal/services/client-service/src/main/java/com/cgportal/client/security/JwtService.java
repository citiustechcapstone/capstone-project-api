package com.cgportal.client.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
 
import javax.crypto.SecretKey;
//import java.nio.charset.StandardCharsets;
import java.util.Base64;
 
@Service
public class JwtService {
    private final SecretKey key;
    private final String issuer;
    
    public JwtService(
            @Value("${cgp.security.jwt.secret}") String secret,
            @Value("${cgp.security.jwt.issuer}") String issuer) {
        byte[] decodedKey = Base64.getDecoder().decode(secret);
        this.key = Keys.hmacShaKeyFor(decodedKey);
        this.issuer = issuer;
    }

    public Jws<Claims> parse(String token) throws JwtException {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .requireIssuer(issuer)
                .build()
                .parseClaimsJws(token);
    }

    public String extractUsername(String token) {
        return parse(token).getBody().get("username", String.class);
    }

    public String extractRole(String token) {
        return parse(token).getBody().get("role", String.class); // Should be "ROLE_ADMIN"
    }

  
}