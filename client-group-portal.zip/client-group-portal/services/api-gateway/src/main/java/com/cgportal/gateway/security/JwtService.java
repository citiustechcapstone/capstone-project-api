package com.cgportal.gateway.security;

import java.util.Date;
import javax.crypto.SecretKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;

@Service
public class JwtService {

	@Value("${cgp.security.jwt.secret}")
	private String secretBase64;

	private SecretKey key;

	@PostConstruct
	public void init() {
		byte[] keyBytes = Decoders.BASE64.decode(secretBase64);
		if (keyBytes.length < 32) {
			throw new IllegalStateException("JWT secret too short for HS256. Provide at least 32 bytes (256 bits).");
		}
		this.key = Keys.hmacShaKeyFor(keyBytes);
	}

	public boolean isTokenValid(String token) {
		try {
			Claims claims = claims(token);
			return claims.getExpiration() != null && claims.getExpiration().after(new Date());
		} catch (Exception e) {
			return false;
		}
	}

	public Claims claims(String token) {
		return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();
	}

	public String username(String token) {
		return claims(token).getSubject();
	}

	public String role(String token) {
		Object r = claims(token).get("role");
		return r == null ? null : r.toString();
	}
}
