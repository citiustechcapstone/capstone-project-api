-- Parent
INSERT INTO client_groups (group_id, parent_group_id, c_code, group_name, effective_date, termination_date,
                           address1, address2, city, state, zip, phone, status, created_by)
VALUES ('1000000001', NULL, 'C001', 'Parent Alpha', '2024-01-01', '2099-12-31',
        '100 Main St', NULL, 'Pune', 'MH', '411001', '+91-9999999999', 'ACTIVE', 'seed');
 
-- Child (parent references ID of parent row)
INSERT INTO client_groups (group_id, parent_group_id, c_code, group_name, effective_date, termination_date,
                           address1, address2, city, state, zip, phone, status, created_by)
VALUES ('1000000002', (SELECT id FROM client_groups WHERE group_id='1000000001'), 'C002', 'Child Beta',
        '2024-01-01', '2099-12-31', '200 Park Ave', NULL, 'Mumbai', 'MH', '400001', '+91-8888888888', 'ACTIVE', 'seed');
 
-- Contacts
INSERT INTO contacts (client_group_id, contact_type, first_name, last_name, title, preferred_receipt_method,
                      email, phone, effective_date, termination_date, created_by)
VALUES
((SELECT id FROM client_groups WHERE group_id='1000000001'), 'ACCOUNTING','Anita','Shah','Mrs','EMAIL','anita.parent@example.com',
'+91-7777777777','2024-01-01','2099-12-31','seed'),
((SELECT id FROM client_groups WHERE group_id='1000000002'), 'BROKER','Rahul','Mehta','Mr','FAX','rahul.child@example.com',
'+91-6666666666','2024-01-01','2099-12-31','seed');
 
-- Products
INSERT INTO product_enrollments (client_group_id, product_type, description, effective_date, termination_date, created_by)
VALUES
((SELECT id FROM client_groups WHERE group_id='1000000001'), 'GROUP_HEALTH','Group Health coverage for registered group.','2024-01-01','2099-12-31','seed'),
((SELECT id FROM client_groups WHERE group_id='1000000002'), 'FULLY_INSURED','Fully Insured product with fixed premiums.','2024-01-01','2099-12-31','seed');