package com.cgportal.client.mapper;

import com.cgportal.client.dto.ProductEnrollmentDto;
import com.cgportal.client.model.ProductEnrollment;

import org.mapstruct.*;
 
@Mapper(componentModel = "spring")
public interface ProductEnrollmentMapper {
  ProductEnrollmentDto toDto(ProductEnrollment e);
  ProductEnrollment toEntity(ProductEnrollmentDto dto);
 
  @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
  void update(@MappingTarget ProductEnrollment target, ProductEnrollmentDto src);
}