package com.cgportal.client.dto;

public record CreateCredentialResponse(String username, String tempPassword) {
}