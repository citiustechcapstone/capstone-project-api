package com.cgportal.client.service;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import com.cgportal.client.dto.ProductEnrollmentDto;
import com.cgportal.client.mapper.ProductEnrollmentMapper;
import com.cgportal.client.model.ProductEnrollment;
import com.cgportal.client.repo.ProductEnrollmentRepository;

import java.util.List;
import java.util.Map;

@Service
public class ProductService {
	private final ProductEnrollmentRepository repo;
	private final ProductEnrollmentMapper mapper;

	private static final Map<String, String> DESCRIPTIONS = Map.of("GROUP_HEALTH", "Group Health Coverage",
			"FULLY_INSURED", "Fully Insured Product", "SELF_INSURED", "Self Insured Product");

	public ProductService(ProductEnrollmentRepository repo, ProductEnrollmentMapper mapper) {
		this.repo = repo;
		this.mapper = mapper;
	}

	public List<ProductEnrollmentDto> list(Long clientGroupId) {
		return repo.findByClientGroupId(clientGroupId).stream().map(mapper::toDto).toList();
	}

	@Transactional
	public ProductEnrollmentDto upsert(ProductEnrollmentDto dto) {

		String desc = (dto.getDescription() != null && !dto.getDescription().isBlank()) ? dto.getDescription()
				: DESCRIPTIONS.getOrDefault(dto.getProductType(), "N/A");

		if (dto.getId() == null) {
			ProductEnrollment e = mapper.toEntity(dto);
			e.setDescription(desc);
			return mapper.toDto(repo.save(e));
		} else {
			ProductEnrollment e = repo.findById(dto.getId()).orElseThrow();
			mapper.update(e, dto);
			e.setDescription(desc);
			return mapper.toDto(repo.save(e));
		}
	}

	public ProductEnrollmentDto view(Long clientGroupId, Long id) {
		return repo.findByIdAndClientGroupId(id, clientGroupId).map(mapper::toDto)
				.orElseThrow(() -> new EntityNotFoundException("Product not found"));
	}

	@Transactional
	public ProductEnrollmentDto edit(Long clientGroupId, Long id, ProductEnrollmentDto dto) {
		ProductEnrollment entity = repo.findByIdAndClientGroupId(id, clientGroupId)
				.orElseThrow(() -> new EntityNotFoundException("Product not found"));

		String desc = (dto.getDescription() == null || dto.getDescription().isBlank())
				? DESCRIPTIONS.getOrDefault(dto.getProductType(), "N/A")
				: dto.getDescription();

		mapper.update(entity, new ProductEnrollmentDto(id, clientGroupId, dto.getProductType(), desc,
				dto.getEffectiveDate(), dto.getTerminationDate()));

		return mapper.toDto(repo.save(entity));
	}

	public void delete(Long clientGroupId, Long id) {
		ProductEnrollment entity = repo.findByIdAndClientGroupId(id, clientGroupId)
				.orElseThrow(() -> new EntityNotFoundException("Product not found"));
		repo.delete(entity);
	}
}

