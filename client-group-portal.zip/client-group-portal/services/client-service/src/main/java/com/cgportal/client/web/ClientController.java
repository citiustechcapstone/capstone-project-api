package com.cgportal.client.web;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.Map;

import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.cgportal.client.dto.ClientGroupDto;
import com.cgportal.client.dto.ContactDto;
import com.cgportal.client.dto.ProductEnrollmentDto;
import com.cgportal.client.s2s.AuthClient;
import com.cgportal.client.service.ClientGroupService;
import com.cgportal.client.service.ContactService;
import com.cgportal.client.service.ProductService;

@RestController
@RequestMapping("/clients")
public class ClientController {

	private final ClientGroupService clients;
	private final ContactService contacts;
	private final ProductService products;
	private final AuthClient authClient;

	public ClientController(ClientGroupService clients, ContactService contacts, ProductService products,
			AuthClient authClient) {
		this.clients = clients;
		this.contacts = contacts;
		this.products = products;
		this.authClient = authClient;
	}

	// Search
	@GetMapping
	public Page<ClientGroupDto> search(@RequestParam(required = false) String groupId,
			@RequestParam(required = false) String groupName, @RequestParam(required = false) String cCode,
			@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size,
			@RequestParam(defaultValue = "groupName,asc") String sort) {
		Sort s = Sort.by(sort.split(",")[0]).ascending();
		if (sort.toLowerCase().endsWith("desc"))
			s = s.descending();
		return clients.search(groupId, groupName, cCode, PageRequest.of(page, size, s));
	}

	// Create client (ADMIN)

	@PostMapping
	public ClientGroupDto create(@Valid @RequestBody ClientGroupDto dto) {
		return clients.create(dto);
	}

	// Profile
	@GetMapping("/{id}")
	public ClientGroupDto get(@PathVariable Long id) {
		return clients.get(id);
	}

	// Update (ADMIN)
	@PutMapping("/{id}")
	public ClientGroupDto update(@PathVariable Long id, @Valid @RequestBody ClientGroupDto dto) {
		return clients.update(id, dto);
	}

	// Contacts
	@GetMapping("/{id}/contact")
	public java.util.List<ContactDto> contacts(@PathVariable Long id) {
		return contacts.list(id);
	}

	@PostMapping("/{id}/contacts/upsert") // done
	public ContactDto upsertContact(@PathVariable Long id, @Valid @RequestBody ContactDto dto) {
		return contacts.upsert(new ContactDto(dto.getId(), id, dto.getContactType(), dto.getFirstName(),
				dto.getLastName(), dto.getTitle(), dto.getPreferredReceiptMethod(), dto.getEmail(), dto.getPhone(),
				dto.getEffectiveDate(), dto.getTerminationDate()));
	}

	// Products
	@GetMapping("/{id}/product")
	public java.util.List<ProductEnrollmentDto> products(@PathVariable Long id) {
		return products.list(id);
	}

	@PostMapping("/{id}/products/upsert")
	public ProductEnrollmentDto upsertProduct(@PathVariable Long id, @Valid @RequestBody ProductEnrollmentDto dto) {
		return products.upsert(new ProductEnrollmentDto(dto.getId(), id, dto.getProductType(), dto.getDescription(),
				dto.getEffectiveDate(), dto.getTerminationDate()));
	}

	// Credential linkage: calls auth-service to create a CLIENT user bound to this
	// clientGroupId
	@PostMapping("/{id}/credentials")
	public ResponseEntity<?> createCredentials(@PathVariable Long id, @RequestHeader("Authorization") String bearer,
			@RequestBody Map<String, String> body) {
		// body may include username/password; we inject role + clientGroupId
		var req = new java.util.HashMap<String, Object>();
		req.putAll(body);
		req.putIfAbsent("role", "CLIENT");
		// fetch client for groupId
		var cg = clients.get(id);
		req.put("clientGroupId", cg.getGroupId());
		var resp = authClient.register(req, bearer);
		return ResponseEntity.ok(resp);
	}

	@GetMapping("/{id}/products/{pid}")
	public ProductEnrollmentDto viewProduct(@PathVariable Long id, @PathVariable("pid") Long pid) {
		return products.view(id, pid);
	}

	@PutMapping("/{id}/products/{pid}")
	public ProductEnrollmentDto editProduct(@PathVariable Long id, @PathVariable("pid") Long pid,
			@Valid @RequestBody ProductEnrollmentDto dto) {
		return products.edit(id, pid, dto); // No need to reconstruct DTO
	}

	@DeleteMapping("/{id}/products/{pid}")
	public void deleteProduct(@PathVariable Long id, @PathVariable("pid") Long pid) {
		products.delete(id, pid);
	}


}