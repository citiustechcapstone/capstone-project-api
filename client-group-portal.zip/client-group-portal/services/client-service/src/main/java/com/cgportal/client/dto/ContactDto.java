package com.cgportal.client.dto;

import java.time.LocalDate;

import com.cgportal.client.model.ContactType;
import com.cgportal.client.model.PreferredReceiptMethod;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class ContactDto {
	Long id;
    @NotNull Long clientGroupId;
    @NotNull ContactType contactType;
    @NotBlank String firstName;
    @NotBlank String lastName;
    String title;
    PreferredReceiptMethod preferredReceiptMethod;
    @Email String email;
    String phone;
    @NotNull LocalDate effectiveDate;
    @NotNull LocalDate terminationDate;
    
	public ContactDto(Long id, @NotNull Long clientGroupId, @NotNull ContactType contactType,
			@NotBlank String firstName, @NotBlank String lastName, String title,
			PreferredReceiptMethod preferredReceiptMethod, @Email String email, String phone,
			@NotNull LocalDate effectiveDate, @NotNull LocalDate terminationDate) {
		super();
		this.id = id;
		this.clientGroupId = clientGroupId;
		this.contactType = contactType;
		this.firstName = firstName;
		this.lastName = lastName;
		this.title = title;
		this.preferredReceiptMethod = preferredReceiptMethod;
		this.email = email;
		this.phone = phone;
		this.effectiveDate = effectiveDate;
		this.terminationDate = terminationDate;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getClientGroupId() {
		return clientGroupId;
	}
	public void setClientGroupId(Long clientGroupId) {
		this.clientGroupId = clientGroupId;
	}
	public ContactType getContactType() {
		return contactType;
	}
	public void setContactType(ContactType contactType) {
		this.contactType = contactType;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public PreferredReceiptMethod getPreferredReceiptMethod() {
		return preferredReceiptMethod;
	}
	public void setPreferredReceiptMethod(PreferredReceiptMethod preferredReceiptMethod) {
		this.preferredReceiptMethod = preferredReceiptMethod;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public LocalDate getTerminationDate() {
		return terminationDate;
	}
	public void setTerminationDate(LocalDate terminationDate) {
		this.terminationDate = terminationDate;
	}
    
}
