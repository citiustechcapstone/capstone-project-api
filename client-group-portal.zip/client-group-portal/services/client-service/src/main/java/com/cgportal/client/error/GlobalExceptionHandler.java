package com.cgportal.client.error;
import jakarta.validation.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

 @ExceptionHandler(IllegalArgumentException.class)
 public ResponseEntity<Map<String,Object>> badRequest(IllegalArgumentException ex) {
     return ResponseEntity.badRequest().body(Map.of(
             "type","about:blank",
             "title","Bad Request",
             "detail", ex.getMessage()
     ));
 }

 @ExceptionHandler({MethodArgumentNotValidException.class, ConstraintViolationException.class})
 public ResponseEntity<Map<String,Object>> validation(Exception ex) {
     return ResponseEntity.badRequest().body(Map.of(
             "type","about:blank",
             "title","Validation Failed",
             "detail", ex.getMessage()
     ));
 }

 @ExceptionHandler(DataIntegrityViolationException.class)
 public ResponseEntity<Map<String,Object>> conflict(DataIntegrityViolationException ex) {
     return ResponseEntity.status(409).body(Map.of(
             "type","about:blank",
             "title","Conflict",
             "detail","Unique or referential constraint violated"
     ));
 }
}
