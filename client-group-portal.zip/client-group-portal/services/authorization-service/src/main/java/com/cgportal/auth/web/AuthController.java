package com.cgportal.auth.web;

import com.cgportal.auth.dto.LoginRequest;
import com.cgportal.auth.dto.TokenResponse;
import com.cgportal.auth.model.User;
import com.cgportal.auth.repo.UserRepository;
import com.cgportal.auth.security.JwtService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

	private final AuthenticationManager authManager;
	private final JwtService jwt;
	private final UserRepository users;
	private final PasswordEncoder encoder;

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginRequest request) {
		User user = users.findByUsername(request.getUsername())
				.orElseThrow(() -> new UsernameNotFoundException("User not found"));

		if (!encoder.matches(request.getPassword(), user.getPassword())) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
		}

		Map<String, Object> claims = Map.of("username", user.getUsername(), "role", "ROLE_" + user.getRole());

		String token = jwt.createToken(user.getUsername(), claims);

		return ResponseEntity.ok(Map.of("token", token));
	}
//  public ResponseEntity<TokenResponse> login(@Valid @RequestBody LoginRequest req) {
//    Authentication auth = authManager.authenticate(
//      new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword()));
//    String role = auth.getAuthorities().stream().findFirst().map(Object::toString).orElse("ROLE_CLIENT");
//    String token = jwt.createToken(req.getUsername(), Map.of("role", role));
//    return ResponseEntity.ok(new TokenResponse(token, 3600));
//  }

	@PostMapping("/register")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<?> register(@RequestBody Map<String, Object> body) {
		String username = String.valueOf(body.get("username"));
		String password = String.valueOf(body.get("password"));
		String role = String.valueOf(body.getOrDefault("role", "CLIENT")).toUpperCase();
		if (users.findByUsername(username).isPresent()) {
			return ResponseEntity.badRequest().body(Map.of("message", "User already exists"));
		}
		User u = new User();
		u.setUsername(username);
		u.setPassword(encoder.encode(password));
		u.setRole(role);
		u.setEnabled(true);
		users.save(u);
		return ResponseEntity.ok(Map.of("id", u.getId(), "username", u.getUsername(), "role", u.getRole()));
	}

	@GetMapping("/validate")
	public ResponseEntity<?> validate() {
		return ResponseEntity.ok(Map.of("status", "OK"));
	}
	/*
	 * @GetMapping("/encode-password") public ResponseEntity<?>
	 * encodePassword(@RequestParam String rawPassword) { String encoded =
	 * encoder.encode(rawPassword); return
	 * ResponseEntity.ok(Map.of("encodedPassword", encoded)); }
	 */
}
