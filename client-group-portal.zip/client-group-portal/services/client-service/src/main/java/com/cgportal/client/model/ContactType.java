package com.cgportal.client.model;

public enum ContactType { ACCOUNTING, BROKER, CONSULTANT, INVOICE, CEO }