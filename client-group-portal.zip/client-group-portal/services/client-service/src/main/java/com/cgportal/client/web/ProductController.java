package com.cgportal.client.web;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.cgportal.client.dto.ProductEnrollmentDto;
import com.cgportal.client.service.ProductService;

import java.util.List;
 
@RestController
@RequestMapping("/clients/{clientId}/products")
@RequiredArgsConstructor
public class ProductController {
 
    private final ProductService service;
 
    @GetMapping
    public List<ProductEnrollmentDto> list(@PathVariable Long clientId) {
        return service.list(clientId);
    }
 
    @PostMapping
    public ResponseEntity<ProductEnrollmentDto> upsert(@PathVariable Long clientId,
                                                       @RequestBody @Valid ProductEnrollmentDto dto,
                                                       Authentication principal) {
        requireAdmin(principal);
        if (!clientId.equals(dto.getClientGroupId()))
            throw new IllegalArgumentException("clientGroupId mismatch");
        return ResponseEntity.ok(service.upsert(dto));
    }
 
    private void requireAdmin(Authentication principal) {
        if (principal == null || principal.getAuthorities().stream().noneMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            throw new IllegalArgumentException("Admin privileges required");
        }
    }
}