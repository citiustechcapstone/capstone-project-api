package com.cgportal.client.mapper;

import com.cgportal.client.dto.ClientGroupDto;
import com.cgportal.client.model.ClientGroup;

import org.mapstruct.*;
 
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ClientGroupMapper {
  ClientGroupDto toDto(ClientGroup entity);
  ClientGroup toEntity(ClientGroupDto dto);
 
  @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)

@Mappings({@Mapping(target = "cCode", source = "cCode")})

  void update(@MappingTarget ClientGroup entity, ClientGroupDto dto);
}