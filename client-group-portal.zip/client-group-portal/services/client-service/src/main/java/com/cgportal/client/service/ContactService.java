package com.cgportal.client.service;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cgportal.client.dto.ContactDto;
import com.cgportal.client.mapper.ContactMapper;
import com.cgportal.client.model.Contact;
import com.cgportal.client.repo.ClientGroupRepository;
import com.cgportal.client.repo.ContactRepository;

import java.util.List;
 
@Service
public class ContactService {
	  private final ContactRepository repo;
	  private final ContactMapper mapper;
	 
	  public ContactService(ContactRepository repo, ContactMapper mapper) {
	    this.repo = repo; this.mapper = mapper;
	  }
	 
	  public List<ContactDto> list(Long clientGroupId) {
	    return repo.findByClientGroupId(clientGroupId).stream().map(mapper::toDto).toList();
	  }
	 
	  @Transactional
	  public ContactDto upsert(ContactDto dto) {
	    if (dto.getId()==null) {
	      Contact e = mapper.toEntity(dto);
	      return mapper.toDto(repo.save(e));
	    } else {
	      Contact e = repo.findById(dto.getId()).orElseThrow();
	      mapper.update(e, dto);
	      return mapper.toDto(repo.save(e));
	    }
	  }
}