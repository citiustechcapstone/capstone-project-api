package com.cgportal.auth.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.*;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;

import java.util.function.Function;

@Service
public class JwtService {

	@Value("${cgp.security.jwt.secret}")
	String secretBase64;

	@Value("${cgp.security.jwt.issuer:client-group-portal-authorization-service}")
	private String issuer;

	@Value("${JWT_SECRET:dev-secret-change-me}")
	private String secretRaw;

	@Value("${JWT_EXPIRES_SECONDS:3600}")
	private long expiresSeconds;

	private SecretKey key;

	@PostConstruct
	void init() {
		if (secretBase64 != null && !secretBase64.isBlank()) {
			byte[] bytes = Decoders.BASE64.decode(secretBase64);
			this.key = Keys.hmacShaKeyFor(bytes);
		} else {
			byte[] bytes = secretRaw.getBytes(StandardCharsets.UTF_8);
			this.key = Keys.hmacShaKeyFor(bytes);
		}
	}

	public String createToken(String subject, Map<String, Object> claims) {
		long now = System.currentTimeMillis();
		return Jwts.builder().setSubject(subject).setClaims(claims).setIssuedAt(new Date(now))
				.setExpiration(new Date(now + (expiresSeconds * 1000))).setIssuer(issuer)
				.signWith(key, SignatureAlgorithm.HS256).compact();
	}

//	public String createToken(String subject, Map<String, Object> claims) {
//		long now = System.currentTimeMillis();
//		return Jwts.builder().setSubject(subject).setClaims(claims).setIssuedAt(new Date(now))
//				.setExpiration(new Date(now + (expiresSeconds * 1000))).signWith(key, SignatureAlgorithm.HS256)
//				.setIssuer("client-group-portal-auth-service")
//				.compact();
//	}

	public String extractUsername(String token) {
		return extractClaim(token, Claims::getSubject);
	}

	// ✅ Validate token against user details
	public boolean isTokenValid(String token, UserDetails userDetails) {
		final String username = extractUsername(token);
		return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}

	// ✅ Check if token is expired
	private boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

	// ✅ Extract expiration date
	private Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}

	// ✅ Generic claim extractor
	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}

	// ✅ Extract all claims from token
	private Claims extractAllClaims(String token) {
		return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();
	}

	public String extractRole(String token) {
		Claims claims = extractAllClaims(token);
		return claims.get("role", String.class); // Should return "ROLE_ADMIN"
	}

}