package com.cgportal.client.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cgportal.client.model.ProductEnrollment;

import java.util.List;
import java.util.Optional;
 
public interface ProductEnrollmentRepository extends JpaRepository<ProductEnrollment, Long> {
    List<ProductEnrollment> findByClientGroupId(Long clientGroupId);
    Optional<ProductEnrollment> findByIdAndClientGroupId(Long id, Long clientGroupId);
}