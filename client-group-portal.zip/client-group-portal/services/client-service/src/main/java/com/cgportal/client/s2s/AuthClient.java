package com.cgportal.client.s2s;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

//@FeignClient(name = "authClient", url = "${auth.service.base-url:http://localhost:8081}")

@FeignClient(name = "auth-service", url = "${auth.service.url:http://localhost:8081}")
public interface AuthClient {

@PostMapping("/auth/register")
Map<String, Object> register(@RequestBody Map<String, Object> body,
                            @RequestHeader("Authorization") String bearer);
}
