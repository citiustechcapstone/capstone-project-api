package com.cgportal.client.dto;

import java.time.LocalDate;

import com.cgportal.client.model.ProductType;

import jakarta.validation.constraints.NotNull;

public class ProductEnrollmentDto {
	Long id;
    @NotNull Long clientGroupId;
    @NotNull ProductType productType;
    String description; // derived server-side
    @NotNull LocalDate effectiveDate;
    @NotNull LocalDate terminationDate;
    
    
	public ProductEnrollmentDto(Long id, @NotNull Long clientGroupId, @NotNull ProductType productType,
			String description, @NotNull LocalDate effectiveDate, @NotNull LocalDate terminationDate) {
		super();
		this.id = id;
		this.clientGroupId = clientGroupId;
		this.productType = productType;
		this.description = description;
		this.effectiveDate = effectiveDate;
		this.terminationDate = terminationDate;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getClientGroupId() {
		return clientGroupId;
	}
	public void setClientGroupId(Long clientGroupId) {
		this.clientGroupId = clientGroupId;
	}
	public ProductType getProductType() {
		return productType;
	}
	public void setProductType(ProductType productType) {
		this.productType = productType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public LocalDate getTerminationDate() {
		return terminationDate;
	}
	public void setTerminationDate(LocalDate terminationDate) {
		this.terminationDate = terminationDate;
	}
    
    
}
